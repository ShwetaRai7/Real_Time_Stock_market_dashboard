# Build-a-Real-time-Stock-Market-Dashboard-using-Power-BI
Developed and deployed personal stock dashboard that fetched real-time prices of stocks and cryptocurrencies using Finance API 

Visualized historical performance of stocks through area graphs and bar charts in Power BI 

Utilized data analysis skills to provide insights into financial trends and patterns
